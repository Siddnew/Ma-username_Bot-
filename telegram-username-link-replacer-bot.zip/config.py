# config.py

BOT_TOKEN = '8064092500:AAED3yenT3qUzlTwq9Dv3M2UKi52FihgieM'
REPLACE_USERNAME = '@MaUsernamechange_Bot'
REPLACE_LINK = 'https://t.me/moviesareavailable1395'
